input UInt32 a, b, c, d, e, f, g, h, i, j, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, aa, bb, cc, dd, ee, ff, gg, hh, ii

output UInt32 final

variable UInt32 t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33

t1 = a + b
t2 = t1 + c
t3 = t2 + d
t4 = t3 + e
t5 = t4 + f
t6 = t5 + g
t7 = t6 + h
t8 = t7 + i
t9 = t8 + j
t10 = t9 + l
t11 = t10 + m
t12 = t11 + n
t13 = t12 + o
t14 = t13 + p
t15 = t14 + q
t16 = t15 + r
t17 = t16 + s
t18 = t17 + t
t19 = t18 + u
t20 = t19 + v
t21 = t20 + w
t22 = t21 + x
t23 = t22 + y
t24 = t23 + z
t25 = t24 + aa
t26 = t25 + bb
t27 = t26 + cc
t28 = t27 + dd
t29 = t28 + ee
t30 = t29 + ff
t31 = t30 + gg
t32 = t31 + hh
t33 = t32 + ii
final = t33 + t1
