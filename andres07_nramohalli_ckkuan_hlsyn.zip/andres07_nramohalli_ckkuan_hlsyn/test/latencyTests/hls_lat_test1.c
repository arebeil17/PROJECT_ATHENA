input Int16 a, b, c, d, e

output Int16 i

variable Int16 f, g, h

f = a + b
g = f + c
h = g + d
i = h + e