/*
* File: Net.cpp
* Author: Andres Rebeil
* NetID: andres07
* Date: December 1st, 2015
*
* Description: This file .cpp file contains the implementation of the input class
*/
/**************************************************************************************************/
#include "net.h"
/**************************************************************************************************/

//Default Constructor
Net::Net()
{

}
/**************************************************************************************************/
