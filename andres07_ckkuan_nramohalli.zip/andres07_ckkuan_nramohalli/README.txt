Andres Rebeil andres07	
Nikitha Ramohalli nramohalli
Kyle Kuan ckkuan
Vivado 2017.2
xc7a100tcsg324-1
For the calculated critical paths we used the component delays determined from synthesis.
We calculated the estimated critical path by finding the path with the largest sum of component
delay.